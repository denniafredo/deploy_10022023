<?php
define('FPDF_FONTPATH','font/');
require('ref_index.php');

//Sort function for references
//To be defined by the user to achieve desired results
//This function is case insensitive
function cmp ($a, $b) {
    return strnatcmp(strtolower($a['t']), strtolower($b['t']));
}

$pdf=new PDF_Ref();
$pdf->Open();
$pdf->SetFont('Arial','',15);

//Page 1
$pdf->AddPage();
$pdf->Cell(0,5,'Page 1',0,1,'C');
$pdf->Reference('Ref1');
$pdf->Reference('Ref90');
$pdf->Reference('A');

//Page 2
$pdf->AddPage();
$pdf->Cell(0,5,'Page 2',0,1,'C');
$pdf->Reference('Ref90');
$pdf->Reference('a');
$pdf->Reference('A');
$pdf->Reference('g');
$pdf->Reference('G');
$pdf->Reference('Nom');
for ($i=1;$i<=350;$i++)
	$pdf->Reference('test'.$i);

//Alphabetic sort of the references
usort($pdf->Reference, 'cmp');

//Creation of index
$pdf->CreateReference(4);
$pdf->Output();
?>
