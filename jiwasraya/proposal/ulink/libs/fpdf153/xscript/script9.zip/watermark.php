<?php
define('FPDF_FONTPATH','font/');
require('rotation.php');

class PDF extends PDF_Rotate
{
function Header()
{
	//Put watermark
	$this->SetFont('Arial','B',50);
	$this->SetTextColor(255,192,203);
	$this->RotatedText(30,190,'W a t e r m a r k   d e m o',45);
}

function RotatedText($x,$y,$txt,$angle)
{
	//Text rotated around its origin
	$this->Rotate($angle,$x,$y);
	$this->Text($x,$y,$txt);
	$this->Rotate(0);
}
}

$pdf=new PDF();
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);
$txt='FPDF is a PHP class which allows to generate PDF files with straight PHP, that is to say '.
	'without using the PDFlib library. The advantage is that the latter requires a fee for a '.
	'commercial usage. F from FPDF stands for Free: you may use it for any kind of usage and '.
	'modify it to suit your needs.';
for($i=0;$i<25;$i++) 
	$pdf->Write(5,$txt);
$pdf->Output();
?>
