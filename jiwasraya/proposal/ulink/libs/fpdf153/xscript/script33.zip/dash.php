<?php
require('fpdf.php');

class PDF extends FPDF
{
	function SetDash($black=false,$white=false)
	{
		if($black and $white)
			$s=sprintf('[%.3f %.3f] 0 d',$black*$this->k,$white*$this->k);
		else
			$s='[] 0 d';
		$this->_out($s);
	}
}

$pdf=new PDF();
$pdf->Open();
$pdf->AddPage();
$pdf->SetLineWidth(0.1);
$pdf->SetDash(5,5); //5mm on, 5mm off
$pdf->Line(20,20,190,20);
$pdf->SetLineWidth(0.5);
$pdf->Line(20,25,190,25);
$pdf->SetLineWidth(0.8);
$pdf->SetDash(4,2); //4mm on, 2mm off
$pdf->Rect(20,30,170,20);
$pdf->SetDash(); //restore no dash
$pdf->Line(20,55,190,55);
$pdf->Output();
?>
