<?php
ini_set('memory_limit','100M');
ini_set('max_execution_time',0);

define('FPDF_FONTPATH','font/');
require('memory_opt.php');

// for testing purposes only stops a bug where command line php
// believes that headers have already been sent

class TESTING_PDF extends PDF_Opt
{

    function Output()
    {
            echo $this->buffer;
    }

}

$pdf = new TESTING_PDF();
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial','',9);
// generate a constant amount of text for testing
for($i=1; $i<200; $i++)
	$txt .= 'ashfsd kjsahkasjh akjhdsfjkh djshf sjkh ' ;
for($i=1; $i<1000; $i++)
	$pdf->Write(9,$txt);
$pdf->Close();
$pdf->Output();

?>
