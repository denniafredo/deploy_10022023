<?php
define('FPDF_FONTPATH','font/');
require('fpdf.php');

class PDF extends FPDF
{
function Table($col,$sql)
{
	global $conn;

	//Query
	$res=odbc_do($conn,$sql);
	if(!$res)
		die('SQL error');

	//Header
	$this->SetFillColor(255,0,0);
	$this->SetTextColor(255);
	$this->SetDrawColor(128,0,0);
	$this->SetLineWidth(.3);
	$this->SetFont('','B');
	$tw=0;
	foreach($col as $label=>$width)
	{
		$tw+=$width;
		$this->Cell($width,7,$label,1,0,'C',1);
	}
	$this->Ln();

	//Rows
	$this->SetFillColor(224,235,255);
	$this->SetTextColor(0);
	$this->SetFont('');
	$fill=0;
	while(odbc_fetch_row($res))
	{
		foreach($col as $field=>$width)
			$this->Cell($width,6,odbc_result($res,$field),'LR',0,'L',$fill);
		$this->Ln();
		$fill=!$fill;
	}
	$this->Cell($tw,0,'','T');
}
}

$conn=odbc_connect('COFFEE','','');
if(!$conn)
	die('Connection failed');
$pdf=new PDF();
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Arial','',14);
$sql='SELECT COFFEE_NAME, ROAST_TYPE, QUANTITY FROM COFFEE_INVENTORY ORDER BY QUANTITY DESC';
$pdf->Table(array('COFFEE_NAME'=>50,'ROAST_TYPE'=>40,'QUANTITY'=>100),$sql);
$pdf->Output();
?>
