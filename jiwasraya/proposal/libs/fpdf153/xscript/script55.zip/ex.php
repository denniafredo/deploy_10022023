<?php
require('fpdf-wmf.php');

$pdf = new FPDF_WMF();
$pdf->AddPage();
$pdf->ImageWMF('ringmaster.wmf', 50, 10, 110);
$pdf->Output();
?>
