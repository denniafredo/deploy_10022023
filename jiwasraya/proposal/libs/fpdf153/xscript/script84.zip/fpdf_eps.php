<?php
require('fpdf.php');

class PDF_EPS extends FPDF{

function ImageEps ($file, $x, $y, $w=0, $h=0, $link='', $useBoundingBox=true){  
	$data = file_get_contents($file);
	if ($data===false) $this->Error('EPS file not found: '.$file);
	
	// find BoundingBox params
	ereg ("%%BoundingBox: ([^\r\n]+)", $data, $regs);
	if (count($regs)>1) list($x1,$y1,$x2,$y2) = explode(' ', $regs[1]);
	else $this->Error('No BoundingBox found in EPS file: '.$file);
	
	$start = strpos($data, '%%EndSetup');
	if ($start===false) $start = strpos($data, '%%EndProlog');
	if ($start===false) $start = strpos($data, '%%BoundingBox');
	
	$data = substr($data, $start);
		
	$end = strpos($data, '%%PageTrailer');
	if ($end===false) $end = strpos($data, 'showpage');
	if ($end) $data = substr($data, 0, $end);
	
	// save the current graphic state
	$this->_out('q');
	
	$k = $this->k;
	
	// Translate
	if ($useBoundingBox){
		$dx = $x*$k-$x1;
		$dy = $this->hPt-$y2-$y*$k;
	}else{
		$dx = $x*$k;
		$dy = -$y*$k;
	}
	$tm = array(1,0,0,1,$dx,$dy);
	$this->_out(sprintf('%.3f %.3f %.3f %.3f %.3f %.3f cm', $tm[0],$tm[1],$tm[2],$tm[3],$tm[4],$tm[5]));
	
	if ($w>0){
		$scale_x = $w/(($x2-$x1)/$k);
		if ($h>0){
			$scale_y = $h/(($y2-$y1)/$k);
		}else{
			$scale_y = $scale_x;
			$h = ($y2-$y1)/$k * $scale_y;
		}
	}else{
		if ($h>0){
			$scale_y = $h/(($y2-$y1)/$k);
			$scale_x = $scale_y;
			$w = ($x2-$x1)/$k * $scale_x;
		}else{
			$w = ($x2-$x1)/$k;
			$h = ($y2-$y1)/$k;
		}
	}
	if (isset($scale_x)) {
		// Scale
		$tm = array($scale_x,0,0,$scale_y,0,$this->hPt*(1-$scale_y));
		$this->_out(sprintf('%.3f %.3f %.3f %.3f %.3f %.3f cm', $tm[0],$tm[1],$tm[2],$tm[3],$tm[4],$tm[5]));
	}

	$lines = split ("\r\n|[\r\n]", $data); // pc/unix/mac line endings
	foreach ($lines as $line){
		if ($line=='' || $line{0}=='%') continue;
		$len = strlen($line);
		if ($len>2 && $line{$len-2}!=' ') continue;
		$cmd = $line{$len-1};
		switch ($cmd){
			case 'm':
			case 'l':
			case 'v':
			case 'y':
			case 'c':
			
			case 'k':
			case 'K':
			case 'g':
			case 'G':
			
			case 's':
			case 'S':
			
			case 'J':
			case 'j':
			case 'w':
			case 'M':
			case 'd' :
				$this->_out($line);
				break;
				
			case 'L':
				$line{$len-1}='l';
				$this->_out($line);
				break;
				
			case 'C':
				$line{$len-1}='c';
				$this->_out($line);
				break;
				
			case 'f':
			case 'F':
				$this->_out('f*');
				break;
				
			case 'b':
			case 'B':
				$this->_out($cmd . '*');
				break;
		}
		
	}
	
	// restore previous graphic state
	$this->_out('Q');
	if ($link)
		$this->Link($x,$y,$w,$h,$link);
}

}

// for backward compatibility
if (!function_exists('file_get_contents')){
	function file_get_contents($filename){
		$file = fopen($filename, 'rb');
		if ($file){
			$fsize = filesize($filename);
			$data = fread($file, $fsize);
			fclose($file);
			return $data;
		}else 
			return false;
	}
}

?>
