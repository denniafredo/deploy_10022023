<?php
define('FPDF_FONTPATH','font/');
require('fpdf.php');

class PDF extends FPDF {

var $DisplayPreferences='';

function DisplayPreferences($preferences) {
	$this->DisplayPreferences.=$preferences;
}

function _putcatalog()
{
	parent::_putcatalog();
	if(is_int(strpos($this->DisplayPreferences,'FullScreen')))
		$this->_out('/PageMode /FullScreen');
	if($this->DisplayPreferences) {
		$this->_out('/ViewerPreferences<<');
		if(is_int(strpos($this->DisplayPreferences,'HideMenubar')))
			$this->_out('/HideMenubar true');
		if(is_int(strpos($this->DisplayPreferences,'HideToolbar')))
			$this->_out('/HideToolbar true');
		if(is_int(strpos($this->DisplayPreferences,'HideWindowUI')))
			$this->_out('/HideWindowUI true');
		if(is_int(strpos($this->DisplayPreferences,'DisplayDocTitle')))
			$this->_out('/DisplayDocTitle true');
		if(is_int(strpos($this->DisplayPreferences,'CenterWindow')))
			$this->_out('/CenterWindow true');
		if(is_int(strpos($this->DisplayPreferences,'FitWindow')))
			$this->_out('/FitWindow true');
		$this->_out('>>');
	}
}
}

$pdf=new PDF();
$pdf->SetDisplayMode('fullpage');
$pdf->DisplayPreferences('HideMenubar,HideToolbar,HideWindowUI');
$pdf->AddPage();
$pdf->SetFont('Arial','',16);
$pdf->Write(6,'Only the document should appear, no interface element.');
$pdf->Output();
?>
