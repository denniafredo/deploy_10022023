<?php
define('FPDF_FONTPATH','font/');
require('fpdf.php');

class PDF extends FPDF
{

	//MultiCell with bullet
	function MultiCellBlt($w,$h,$blt,$txt,$border=0,$align='J',$fill=0)
	{
		//Get bullet width including margins
		$blt_width = $this->GetStringWidth($blt)+$this->cMargin*2;

		//Save x
		$bak_x = $this->x;

		//Output bullet
		$this->Cell($blt_width,$h,$blt,0,'',$fill);
		//Output text
		$this->MultiCell($w-$blt_width,$h,$txt,$border,$align,$fill);

		//Restore x
		$this->x = $bak_x;
	}

}

$pdf=new PDF();
$pdf->Open();
$pdf->AddPage();
$pdf->SetFont('Times','',12);

$column_width = ($pdf->w-30)/2;
$sample_text = 'This is bulleted text. The text is indented and the bullet appears at the first line only.';

for ($n=1; $n<=3; $n++)
	$pdf->MultiCellBlt($column_width,6,chr(149),$sample_text.' '.$sample_text);

for ($n=1; $n<=2; $n++)
	$pdf->MultiCellBlt($column_width,6,'>',$sample_text.' '.$sample_text);

$pdf->SetXY($column_width+10*2,10);
for ($n=1; $n<=10; $n++)
	$pdf->MultiCellBlt($column_width,6,"$n)",$sample_text);

$pdf->Output();
?>
